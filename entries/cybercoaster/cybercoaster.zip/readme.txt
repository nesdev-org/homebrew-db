
Greetings from Fizzer & noby!

We made this game for NES in about 1 month, it's sort of a spiritual successor to Antarctic Adventure... we hope you enjoy it. Game design, code, and graphics by Fizzer. Music and sound effects by noby.

Technical information: 48K ROM using the MMC3 mapper, which is the same mapper used by Super Mario Bros. 3 from 1988. Development of code was done with the ACME assembler and the Mesen2 emulator, and with a bunch of custom tools (including a custom-made "linker").
The music was created in Famitracker and is played back by the FamiTone2 library by Shiru.


How to play:

Move around with the D-Pad, hold A down to accelerate and hold B down to break. When neither A or B are held down, you will continue to move forward at a constant speed. Lateral movements always have the same constant speed. During a game, press start and then select to try the current level again.

The goal of the game is to complete 3 laps of each level before the timer runs out. Each lap adds more time, so it's wise to focus on completing the lap for the first 1 or 2 laps. Each level has 8 spheres to collect, and collecting all of the spheres in a level award you the "Perfect" rating. Collecting all of the spheres is not necessary to proceed to the next level.


Tested on: Mesen, FCEUX, Nestopia, and on a real AV Famicom via an Everdrive N8 Pro.
The game should work in either PAL or NTSC, but there are no speed adjustments for PAL so everything will run slower (including the music) on a PAL NES.

